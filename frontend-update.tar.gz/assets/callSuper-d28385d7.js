import{i as s,ad as c,ae as o}from"./index-8fc149bf.js";function n(r,t,e){return t=s(t),c(r,o()?Reflect.construct(t,e||[],s(r).constructor):t.apply(r,e))}export{n as _};
